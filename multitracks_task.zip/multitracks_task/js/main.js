const stickButton = document.getElementById("isticky");

console.log(stickButton.classList);
window.addEventListener("scroll", () => {
  const currentScroll = window.pageYOffset;
  if (currentScroll > 800) {
    stickButton.classList.add('hide')
  }
  else{
    stickButton.classList.remove('hide')
  }
});
